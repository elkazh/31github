package com.example.demo.repository;

import com.example.demo.domain.Developer;
import com.example.demo.model.DeveloperModel;
import com.example.demo.service.DeveloperService;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public class DeveloperRepository implements DeveloperService {
    @Override
    public DeveloperModel save(Developer developer, MultipartFile file) {
        System.out.println("I am DeveloperRepository object.");
        System.out.println(developer);
        System.out.println(file.getContentType());
        System.out.println(file.getName());
        System.out.println(file.getSize());


        return new DeveloperModel(
                "Model " + developer.firstName(),
                "Model " + developer.lastName(),
                "Model " + developer.phoneNumber());
    }
}


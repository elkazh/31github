package com.example.demo.controller;

import com.example.demo.model.Client;
import com.example.demo.service.ClientService;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Base64;

@Controller
@RequestMapping("/api/client")
public class ClientController {

    private final ClientService clientService;

    public ClientController(ClientService clientService) {
        this.clientService = clientService;
    }

    @PostMapping("/add")
    public ResponseEntity<Client> addNewClient(
            @ModelAttribute Client client
    ) throws IOException {

        System.out.println(client);
        clientService.save(client);
        return ResponseEntity.ok().body(null);
    }


    @GetMapping("/{id}")
    public String getProduct(
            @PathVariable("id") Long id,
            Model model) {
        Client product = clientService.read(id);
        model.addAttribute("product", product);
        model.addAttribute("image", Base64.getEncoder().encodeToString(product.getImage()));

        System.out.println(product);
        return "product";
    }



    @PostMapping(value = "/upload", consumes = { MediaType.MULTIPART_FORM_DATA_VALUE })
    public ResponseEntity<Client> saveClient(
            @RequestPart Client client,
            @RequestPart MultipartFile file) throws IOException {

        System.out.println(client);
        System.out.println(file.getSize());


        Client _client = clientService.save(client, file);
        return ResponseEntity.ok().body(_client);
    }

}

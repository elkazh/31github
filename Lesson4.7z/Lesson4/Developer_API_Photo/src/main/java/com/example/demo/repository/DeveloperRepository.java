package com.example.demo.repository;

import com.example.demo.domain.Developer;
import com.example.demo.model.DeveloperModel;
import com.example.demo.service.DeveloperService;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;

@Service
public class DeveloperRepository implements DeveloperService {

    private final JdbcTemplate jdbcTemplate;

    public DeveloperRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public DeveloperModel save(Developer developer, MultipartFile file) {

/*
CREATE TABLE developers (
id_developer SERIAL PRIMARY KEY,
first_name VARCHAR(255),
last_name VARCHAR(255),
phone_number VARCHAR(255),
photo BYTEA
);
 */
        try {
            String sqlQuery = """
                INSERT INTO developers 
                (first_name, last_name, phone_number, photo) 
                VALUES(?, ?, ?, ?)
                """;
            int answer =  jdbcTemplate.update(
                    sqlQuery,
                    developer.firstName(),
                    developer.lastName(),
                    developer.phoneNumber(),
                    file.getBytes()
            );
            System.out.println("answer " + answer);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }


        return new DeveloperModel(
                developer.firstName(),
                developer.lastName(),
                developer.phoneNumber(),
                file
        );
    }

    @Override
    public DeveloperModel findById(Long id) {
        try {
            DeveloperModel model = jdbcTemplate.queryForObject(
                    "SELECT * FROM developers WHERE id_developer = ?",
                    (rowMapper, row) -> {
                        return new DeveloperModel(
                                rowMapper.getString("first_name"),
                                rowMapper.getString("last_name"),
                                rowMapper.getString("phone_number"),
                                (byte[]) rowMapper.getObject("photo")
                        );
                    },
                    id);

            return model;
        } catch (IncorrectResultSizeDataAccessException e) {
            return null;
        }
    }

}


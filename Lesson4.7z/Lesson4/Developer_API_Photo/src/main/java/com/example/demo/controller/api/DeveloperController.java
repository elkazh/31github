package com.example.demo.controller.api;


import com.example.demo.domain.Developer;
import com.example.demo.model.DeveloperModel;
import com.example.demo.service.DeveloperService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/developers")
public class DeveloperController {

    private final DeveloperService service;

    public DeveloperController(DeveloperService service) {
        this.service = service;
    }


    @GetMapping("/{id}")
    public ResponseEntity<DeveloperModel> readDeveloper(@PathVariable("id") Long id) {
        DeveloperModel model = service.findById(id);

        if (model != null) {
            return new ResponseEntity<>(model, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }


    @PostMapping
    public ResponseEntity<DeveloperModel> saveDeveloper(
            @RequestPart Developer developer,
            @RequestPart MultipartFile file
    ) {
        return new ResponseEntity<>(service.save(developer, file),
                HttpStatus.CREATED);
    }
}

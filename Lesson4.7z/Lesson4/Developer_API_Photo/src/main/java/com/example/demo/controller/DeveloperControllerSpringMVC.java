package com.example.demo.controller;


import com.example.demo.model.DeveloperModel;
import com.example.demo.service.DeveloperService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.ui.Model;
import java.util.Base64;
@Controller
@RequestMapping("/developer")
public class DeveloperControllerSpringMVC {

    private final DeveloperService service;

    public DeveloperControllerSpringMVC(DeveloperService service) {
        this.service = service;
    }

    @GetMapping
    public String readDeveloperForm() {
        return "developer_form";
    }


    @GetMapping("/{id}")
    public String getProduct(
            @PathVariable("id") Long id,
            Model model) {
        DeveloperModel product = service.findById(id);
        model.addAttribute("product", product);
        model.addAttribute("image", Base64.getEncoder().encodeToString(product.getImage()));

        System.out.println(product);
        return "developer_view";
    }


}

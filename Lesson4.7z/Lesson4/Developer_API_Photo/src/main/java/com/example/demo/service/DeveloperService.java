package com.example.demo.service;

import com.example.demo.domain.Developer;
import com.example.demo.model.DeveloperModel;
import org.springframework.web.multipart.MultipartFile;

public interface DeveloperService {
    DeveloperModel save(Developer developer, MultipartFile file);

    DeveloperModel findById(Long id);
}

package com.example.demo.domain;

public record Developer(
        String firstName,
        String lastName,
        String phoneNumber
        ) {
}

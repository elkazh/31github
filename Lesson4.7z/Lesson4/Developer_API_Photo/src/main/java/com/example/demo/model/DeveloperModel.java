package com.example.demo.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.springframework.web.multipart.MultipartFile;

import java.util.Objects;

public class DeveloperModel {
    private final String firstName;
    private final String lastName;
    private final String phoneNumber;
    @JsonIgnore
    private final MultipartFile file;

    @JsonIgnore
    private byte[] images;

    public DeveloperModel(
            String firstName, String lastName,
            String phoneNumber, MultipartFile file) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.phoneNumber = phoneNumber;
        this.file = file;
    }

    public DeveloperModel(
            String firstName, String lastName,
            String phoneNumber, byte[] images) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.phoneNumber = phoneNumber;
        this.file = null;
        this.images = images;
    }



    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public MultipartFile getFile() {
        return file;
    }


    public byte[] getImage() {
        return images;
    }

    @Override
    public String toString() {
        return "DeveloperModel{" +
                "firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", file=" + file +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof DeveloperModel that)) return false;
        return Objects.equals(firstName, that.firstName) && Objects.equals(lastName, that.lastName) && Objects.equals(phoneNumber, that.phoneNumber) && Objects.equals(file, that.file);
    }

    @Override
    public int hashCode() {
        return Objects.hash(firstName, lastName, phoneNumber, file);
    }
}

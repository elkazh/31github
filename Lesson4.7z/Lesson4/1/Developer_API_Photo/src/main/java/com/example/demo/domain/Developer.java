package com.example.demo.domain;

import org.springframework.web.multipart.MultipartFile;

public record Developer(
        String firstName,
        String lastName,
        String phoneNumber,
        MultipartFile file) {
}

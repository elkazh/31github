package com.example.demo.controller.api;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/developer")
public class DeveloperControllerSpringMVC {

    @GetMapping
    public String readDeveloperForm() {
        return "developer_form";
    }

}

package com.example.demo.controller.api;


import com.example.demo.domain.Developer;
import com.example.demo.model.DeveloperModel;
import com.example.demo.service.DeveloperService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/developers")
public class DeveloperController {

    private final DeveloperService service;

    public DeveloperController(DeveloperService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<DeveloperModel> saveDeveloper(
            @ModelAttribute Developer developer
    ) {
        return new ResponseEntity<>(service.save(developer, null),
                HttpStatus.CREATED);
    }
}
